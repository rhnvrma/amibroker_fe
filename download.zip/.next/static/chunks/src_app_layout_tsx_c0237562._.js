(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__404369a3._.css",
  "static/chunks/node_modules_3d823d1a._.js",
  "static/chunks/src_1246dabe._.js"
],
    source: "dynamic"
});
