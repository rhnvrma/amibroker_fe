import { config } from 'dotenv';
config();

import '@/ai/flows/generate-tags-for-watchlist-item.ts';